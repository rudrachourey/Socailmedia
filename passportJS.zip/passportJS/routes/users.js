// const express = require('express');  
var mongoose = require("mongoose");
const passportlocalmongoose = require('passport-local-mongoose');
mongoose.connect("mongodb://127.0.0.1:27017/Passport")
const userSchema= mongoose.Schema({
  email:String,
  name:String,
  username:String,
  password:String,
  Storys:String,
  profileimage:String,
  followers:[{type:mongoose.Schema.Types.ObjectId , ref:"user"}],
  following:[{type:mongoose.Schema.Types.ObjectId,ref:"user"}],
  // cart:[{type:mongoose.Schema.Types.ObjectId,ref:"product"}],
  // posts:[{type:mongoose.Schema.Types.Array , ref:"product"}],
  posts:String,
  like:{
    type:Array,
    default:[]
  }
})
userSchema.plugin(passportlocalmongoose);
module.exports = mongoose.model("user", userSchema);
