var express = require('express');
const passport = require('passport');
const {Strategy} = require('passport-local');
var router = express.Router();
const userModel = require('./users');
const multer = require('multer');
const crypto =require('crypto')
const path =require('path')
const localStrategy = require('passport-local');
const { render } = require('ejs');
passport.use(new localStrategy(userModel.authenticate()));  
/* GET home page. */

var user

function registerOnSocket() {
  console.log(user)
  // socket.emit('register', (user));
}

  router.get('/', function(req, res, next) {
    res.render('index', { title: 'MyApp' });
  }); 

router.get('/profile' ,isLoggedIn,function(req, res, next) {
 userModel.findOne({username: req.session.passport.user})
 .then(function(loggedinUser){
  res.render('profile',{loggedinUser});

 })
});


router.get('/api/users', (req, res) => {
  userModel.findOne((err, users) => {
    if (err) throw err;
    res.json(users);
  });
});



router.get('/login',function(req,res,next){
  res.render('login')
})

router.post('/register', function(req, res, next) {
  var data = new userModel({
    email:req.body.email,
    name:req.body.name,
    username:req.body.username,
  })
  userModel.register(data,req.body.password)
  .then(function(createduser){
    passport.authenticate('local')(req,res,function(){
      res.redirect("/profile")
    })  
  })  
});

function isLoggedIn(req,res,next){
  if(req.isAuthenticated()){
    return next();
  }
  else{res.redirect('/login')}
}


router.post('/login',passport.authenticate('local',{
  successRedirect:'/profile',
  failureRedirect:'/login' 
  }),function(req,res){})







router.get('/like/:id',isLoggedIn,function(req,res){
  // res.send(req.session.passport.user)
  userModel.findOne({_id:req.params.id})  
  .then(function(likehui){
    if(likehui.like.indexOf(likehui._id)=== -1){
      likehui.like.push(likehui._id);
    } 
    else{
      likehui.like.splice(likehui.like.indexOf(likehui._id),1)
    }
    likehui.save()
    .then(function(){
      res.redirect('/allusers')
    })
    })
  });




//////////edit router /////////////


router.get('/edit',isLoggedIn,function(req,res){
    userModel.findOne({username:req.session.passport.user})
    .then(function(loggedinUser){
      res.render('edit',{loggedinUser});
    })
});



router.post('/update', isLoggedIn, function(req, res, next) {
  userModel.findOneAndUpdate({username: req.session.passport.user},
    {username:req.body.username,}) 
  .then(function(user){
  res.redirect("/profile");
  })
});







////////////follow rout/////////////////////////


router.get("/friend/:id",isLoggedIn,function(req,res){
  userModel.findOne({username:req.session.passport.user})
  .then(function(user){
    userModel.findOne({_id:req.params.id})
  .then(function(jiskoFriendBnanaHai){

    user.following.push(jiskoFriendBnanaHai._id);
    jiskoFriendBnanaHai.followers.push(user._id);

     user.save().then(function(){
      jiskoFriendBnanaHai.save().then(function(){
        res.redirect("back");
      })
    })
  // console.log(jiskoFriendBnanaHai)
  })
  });
});




router.get('/remove/Friend/:id',isLoggedIn,function(req,res){
  userModel.findOne({username:req.session.passport.user})
  .then(function(user){
    userModel.findOne({_id:req.params.id})
    .then(function(jisko_splice_krna_hai){
      var index_in_loggedinuser = user.following.indexOf(req.params.id);
      var index_in_anotheraccount = jisko_splice_krna_hai.followers.indexOf(user._id);
      user.following.splice(index_in_loggedinuser,1);  
      jisko_splice_krna_hai.followers.splice(index_in_anotheraccount,1);
      user.save().then(function(){
        jisko_splice_krna_hai.save().then(function(){
          res.redirect("back")
        })
      })    
    })
  })
})





 






///////////////////message section/////////////////////////



router.get('/inbox',isLoggedIn ,(req,res)=>{
  userModel.find({username:req.session.passport.user})
  .then((loggedinUser)=>{
    userModel.find()
    .then((allusers)=>{
      res.render('inbox',{allusers,loggedinUser ,loggedinUser: JSON.stringify(loggedinUser),Allusers: JSON.stringify(allusers)})
      console.log({loggedinUser})
    })
  })
})







////////////////create post rout





router.get("/createproduct",isLoggedIn,function(req,res){
  userModel.findOne({username:req.session.passport.user})
  .then(function(loggedinUser){
    res.render('createproduct',({loggedinUser}))
  })
})









////////////profilepic rout///////////////////////////


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/images/uploads')
  },
  filename: function (req, file, cb) {
    crypto.randomBytes(13, function (err, buff) {
      const fn = buff.toString("hex") + path.extname(file.originalname);
      cb(null, fn);
    })

  }
})


const upload = multer({ storage: storage,  fileFilter:fileFilter})
function fileFilter(req,file,cb){
  if(file.mimetype === "image/jpg" || file.mimetype === "image/jpeg" || file.mimetype === "image/webp" || file.mimetype === "image/png" ){
    cb(null, true);
  }
  else{
    cb(new Error("wrong File Choose"),false);
  }
}




router.post('/upload',isLoggedIn, upload.single('filename'),  function (req, res, next) {
  userModel.findOne({username:req.session.passport.user})
  .then(function(user){
    user.profileimage = req.file.filename;
    user.save()
    .then(function(){
      // console.log({user})
      res.redirect("back");
    })
  })
});








////////////pppppppostsssss   routtttttttt////////////////////////////


const postsstorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './public/images/posts')
    },
    filename: function (req, file, cb) {
      crypto.randomBytes(13, function (err, buff) {
        const fn = buff.toString("hex") + path.extname(file.originalname);
        cb(null, fn);
      })
  
    }
  })
  
  
  const postsupload = multer({ postsstorage,  fileFilter:fileFilter})
  
  function fileFilter(req,file,cb){
    if(file.mimetype === "image/jpg" || file.mimetype === "image/jpeg" ||
     file.mimetype === "image/webp" || file.mimetype === "image/png" ){
      cb(null, true);
    }
    else{
      cb(new Error("wrong File Choose"),false);
    }
  }





  router.post('/postsupload',isLoggedIn, upload.single('posts'), function(req,res,next){
    userModel.findOne({username:req.session.passport.user})
    .then((user)=>{
      user.posts = req.file.posts
      user.save()
      .then(()=>{
        console.log(req.file.posts)
        res.redirect('back')
      })
    })
  })








//////////home pageeeeee///////

router.get('/home', function(req, res, next) {
  userModel.findOne({username:req.session.passport.user})
  .then(function(loggedinUser){
    userModel.find() 
    .then((allusers)=>{
      // console.log({allusers})
      res.render('home',({loggedinUser,allusers}));
    })
  })
});









router.get('/allproduct',isLoggedIn,function(req,res){
  userModel.findOne({username : req.session.passport.user})
  .then(function(user){
    productModel.find().populate("userid")
    .then(function(allUsersproduct){
      console.log(allUsersproduct);
      res.render("home",{allUsersproduct ,user });
    })
   }) 
});


router.get('/post',isLoggedIn,function(req,res){
  userModel.findOne({username : req.session.passport.user})
  .populate({
    path:'post',
    populate:{
      path:'userid'
    }})
  .then(function(user){
    res.render('profile',{user})
  })
});

router.get('/cart/:id',isLoggedIn,function(req,res){
  userModel.findOne({username : req.session.passport.user})
  .then(function(user){
    user.cart.push(req.params.id);
    user.save().then(function(){
      res.redirect("back");
    })
  })
});

router.get('/remove/cart/:id',isLoggedIn,function(req,res){
  userModel.findOne({username : req.session.passport.user})
  .then(function(loggedinUser){
    var index = loggedinUser.cart.indexOf(req.params.id);
    loggedinUser.cart.splice(index);
    loggedinUser.save().then(function(){
      res.redirect("back");
    })
  })
})



////////search//////////////////////



router.post('/getFruits',async function(req, res, next) {
  let payload = req.body.payload.trim();
  let search = await userModel.find({name:{$regex: new RegExp('^'+payload+'.*','i')}}).exec();
  //limit Search results to 10
  search = search.slice(0,10);
  res.send({payload:search})
  // console.log({payload:search});
});











/////////////////////////otheruser profile rout///////////////////////


router.get("/userprofile/:id",isLoggedIn,function(req,res){
  userModel.findById(req.query.id, (err, user) => {
    if (err) {
      // handle any errors that occurred while querying the database
      console.error(err);
      return;
    }
    if (!user) {
      // handle the case where no otheruser with the given ID was found
      console.log('User not found');
      return;
    }
    // console.log(otheruser);
    userModel.findOne({username:req.session.passport.user}).then((loggedinUser)=>{
      res.render('allusers',({user,loggedinUser}))
      
    })
  })
  
})






module.exports = router;


