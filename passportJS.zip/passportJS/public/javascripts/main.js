

var search = document.querySelector("#search")



var flag  = 0
search.addEventListener("click",function(){
    if(flag=== 0){
        document.querySelector('#searchbar').style.display = "initial"
        flag = 1
    }
    else{
        document.querySelector('#searchbar').style.display = "none"
        flag = 0
    }
    // alert("heyy")
})










function sendData(e){
    const searchResults = document.getElementById('bottomsearch')
    var match = e.value.match(/^ [a-zA-Z]*/)

    let match2 = e.value.match(/\s*/);
    if(match2[0]=== e.value){
        searchResults.innerHTML='';
        return;
    }


    // if(match[0] === e.value && e.value.length >= 1 ){
          fetch('getFruits',{
          method: 'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({payload:e.value})
          }).then(res => res.json()).then(data=>{
           let payload = data.payload
        //    console.log(payload )
            searchResults.innerHTML='';
            if(payload.length <1){
            searchResults.innerHTML = '<p>No results found.</p>';
            return;
            }
            payload.forEach((item,index)=>{
                if(index > 0)searchResults.innerHTML+= '<hr>';
                searchResults.innerHTML+=`<div class="searchcard" userId='${item._id}' > 
                <div class="searchpic">
                <img src="../images/uploads/<%=${item.profileimage}%>" alt="">
                </div>
                <div class="searchname">
                  <h3>${item.username}</h3>
                  <h5>${item.name}</h5>
                </div>
                 </div>`  
            });
    
            var searchcard = document.querySelectorAll(".searchcard")


            searchcard.forEach(u=>{
                u.addEventListener('click',function(e){
                        var userID = u.getAttribute('userId')
                        // console.log(userID)
                     window.location = `/userprofile/id?id=${userID}`
                      })
            })

        })
        return;
  }


var searchcard = document.querySelectorAll(".searchcard")


  searchcard.forEach(u=>{
      u.addEventListener('click',function(e){
              // alert('heyy')
            //   console.log('heyy')
              var id = e.getAttribute('userid')
            //   console.log(e.getAttribute('userid'))
           window.location = `/userprofile/id?id=${id}`
            })
  })



    
document.querySelector("#profilepic").addEventListener("click",function(){
    document.querySelector("#file").click();
})

document.querySelector("#file").addEventListener("change",function(){
    document.querySelector("#file-form").submit();
})
   


document.querySelector("#slecet").addEventListener("click",function(){
    document.querySelector("#file-posts #file").click();
})

document.querySelector("#file-posts #file").addEventListener("change",function(){
    document.querySelector("#file-posts").submit();
})

document.querySelector("#createicon").addEventListener("click",function(){
    document.querySelector("#createpost").style.display = 'initial'


})







